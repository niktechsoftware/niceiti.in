<?php
echo "cceMarksDetail";