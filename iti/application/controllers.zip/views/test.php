
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
<head><title>
	Ram Doot International school
</title><link href="css/bk_main.css" rel="stylesheet" type="text/css" /><link href="menu.css" rel="stylesheet" type="text/css" />
    <script src="menu.js" type="text/javascript"></script>
    <script src="jquery.js" type="text/javascript"></script>
    
    <style type="text/css">
        .style3
        {
            font-family: Calibri;
            font-size: 30px;
           
            color: #443266;
             height: 42px;
        border-bottom: 2px solid #443266;
        }
        .style4
        {
            font-family: Arial, Helvetica, sans-serif;
            font-size: small;
            text-align:justify;
            color:#333333;
             
        }
        .style5
        {
            text-align: justify;
        }
    </style>

    <style type="text/css">
        .st1
        {
            color: white;
        }
        
        .st3
        {
            color: white;
        }
        .st2
        {
            font-family: "Courier New", Courier, monospace;
            font-size: 14px;
        }
        
        .styl1
        {
            color: #FFCC00;
        }
        .st7
        {
            color: #99FF66;
        }
    </style>
</head>
<body>
    
 
     
      <?php include"header.php" ?>
   

      <div id="main">
     <div id="main_sub">
   
       <?php include"sidemenu.php" ?>
         <div style="float:right; width:660px; margin-top:30px; margin-right:20px;">
             
    <div class="style3">Expenditure-Head Wise
    </div><br />
   
    <div>
     <div>
	<table cellspacing="2" cellpadding="3" rules="all" id="ContentPlaceHolder1_GridView1" style="background-color:#DEBA84;border-color:#DEBA84;border-width:1px;border-style:None;font-size:Small;width:616px;">
		<tr style="color:White;background-color:#A55129;font-weight:bold;">
			<th scope="col">particulars</th><th scope="col">2016</th><th scope="col">2015</th><th scope="col">2014</th>
		</tr>
		<tr style="color:#8C4510;background-color:#FFF7E7;">	<td>composite Science Lab</td><td>0</td><td>0</td><td>70675</td></tr>
		<tr style="color:#8C4510;background-color:#FFF7E7;">	<td>Physics lab</td><td>50000</td><td>25000</td><td>0</td></tr>
			<tr style="color:#8C4510;background-color:#FFF7E7;"><td>Chemistry lab</td><td>70000</td><td>35000</td><td>0</td></tr>
		<tr style="color:#8C4510;background-color:#FFF7E7;">	<td>Biology lab</td><td>50500</td><td>25250</td><td>0</td></tr>
			<tr style="color:#8C4510;background-color:#FFF7E7;"><td>Mathmetics Lab</td><td>5000</td><td>5000</td><td>15000</td></tr>
			<tr style="color:#8C4510;background-color:#FFF7E7;"><td>Computer lab</td><td>150000</td><td>95360</td><td>64350</td></tr>
		
	</table>
</div>
</div>
                        <br />
                        
                <div class="style3">Class Room Details
    </div><br />
   
    <div>
     <div>
	<table cellspacing="2" cellpadding="3" rules="all" id="ContentPlaceHolder1_GridView1" style="background-color:#DEBA84;border-color:#DEBA84;border-width:1px;border-style:None;font-size:Small;width:616px;">
		<tr style="color:White;background-color:#A55129;font-weight:bold;">
			<th scope="col">Sr.no</th><th scope="col">particulars</th><th scope="col">No Of Rooms</th><th scope="col">size in fit</th>
		</tr>
		<tr style="color:#8C4510;background-color:#FFF7E7;">	<td>1</td><td>class Rooms </td><td>8</td><td>20x25</td></tr>
		<tr style="color:#8C4510;background-color:#FFF7E7;">	<td>2</td><td>Computer Lab</td><td>1</td><td>25x40</td></tr>
			<tr style="color:#8C4510;background-color:#FFF7E7;"><td>3</td><td>Library</td><td>1</td><td>35x40</td></tr>
		<tr style="color:#8C4510;background-color:#FFF7E7;">	<td>4</td><td>Math Lab</td><td>1</td><td>20x25</td></tr>
			<tr style="color:#8C4510;background-color:#FFF7E7;"><td>5</td><td>Physics Lab</td><td>1</td><td>25x40</td></tr>
			<tr style="color:#8C4510;background-color:#FFF7E7;"><td>6</td><td>Chemistry Lab</td><td>1</td><td>25x40</td></tr>
			<tr style="color:#8C4510;background-color:#FFF7E7;"><td>7</td><td>Biology Lab</td><td>1</td><td>25x40</td></tr>
		<tr style="color:#8C4510;background-color:#FFF7E7;">	<td>8</td><td>Vacant Class Rooms</td><td>13</td><td>20x25</td></tr>
			<tr style="color:#8C4510;background-color:#FFF7E7;"><td>9</td><td>Activity/ Music Room</td><td>1</td><td>20x25</td></tr>
			<tr style="color:#8C4510;background-color:#FFF7E7;"><td>10</td><td>Staff Room</td><td>1</td><td>15x36</td></tr>
			<tr style="color:#8C4510;background-color:#FFF7E7;"><td>11</td><td>Sports Room</td><td>1</td><td>20x10</td></tr>
		
	</table>
</div>         </div>

    <br />
                        
                <div class="style3">Details Of Toilets And Tab
    </div><br />
   
    <div>
     <div>
	<table cellspacing="2" cellpadding="3" rules="all" id="ContentPlaceHolder1_GridView1" style="background-color:#DEBA84;border-color:#DEBA84;border-width:1px;border-style:None;font-size:Small;width:616px;">
		<tr style="color:White;background-color:#A55129;font-weight:bold;">
			<th scope="col">Sr.no</th><th scope="col">particulars</th><th scope="col">Boys</th><th scope="col">Girls</th><th scope="col">Staff</th>
		</tr>
		<tr style="color:#8C4510;background-color:#FFF7E7;">	<td>1</td><td>class Rooms </td><td>12</td><td>10</td><td>2</td></tr>
		<tr style="color:#8C4510;background-color:#FFF7E7;">	<td>2</td><td>Computer Lab</td><td>15</td><td>08</td><td>2</td></tr>
			
	</table>
</div>         
                        
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
    </div>
    
        </div>
   
         
    </div>
    


   
     
    </div>
   <?php include"footer.php" ?>
</body>

<!-- Mirrored from rajschool.com/m_school.aspx by HTTrack Website Copier/3.x [XR&CO'2013], Fri, 08 Apr 2016 15:31:49 GMT -->
</html>